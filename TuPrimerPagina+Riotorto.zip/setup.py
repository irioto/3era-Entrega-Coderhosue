from setuptools import setup

setup(
    name='django_ejemplo',
    version='0.1',
    packages=['mi_primer_app'],
    author="Ignacio",
    author_email="ignacioriotorto@gmail.com",
)