from django.shortcuts import render
from django.http import HttpResponse
from django.urls import path
from mi_primer_app.models import Familiar
# Create your views here.


def saludo(request):
      return HttpResponse ("Hola mundo")

urlpatterns = [
    path('hola-mundo/', saludo)
]

def saludo_con_template (request):
      return render (request, 'mi_primer_app/saludo.html')
      
def crear_familiar (request, nombre):
      if nombre is not None:
            nuevo_familiar = Familiar( 
                nombre= nombre,
                apellido= "Perez",
                edad= 30,
                fecha_nacimiento= "1993-01-01",
                parentesco= "Primo"
            )
            nuevo_familiar.save()
      return render(request,"mi_primer_app/crear_familiar.html", {"nombre":nombre})

      
