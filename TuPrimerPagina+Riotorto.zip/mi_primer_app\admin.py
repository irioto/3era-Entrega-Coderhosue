from django.contrib import admin

# Register your models here.
from .models import Familiar, Curso, Deportes

register_models = [Familiar, Curso, Deportes]

admin.site.register(register_models)