from django.apps import AppConfig


class MiPrimerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mi_primer_app'
